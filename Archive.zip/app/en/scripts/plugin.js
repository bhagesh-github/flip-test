window.jQuery = $ = require('jquery')
window.Slick = require('slick-carousel')
window.velocity = $.velocity = require('velocity-animate')
window.datepicker = require('bootstrap-datepicker')
window.uirangeslider = require('nouislider')
window.matchHeight = require('jquery-match-height')
window.magnificPopup = require('magnific-popup')
window.scrollbar = require('malihu-custom-scrollbar-plugin')
// require('gsap')
// window.ScrollMagic = require('scrollmagic')
// require("script-loader!../../../node_modules/scrollmagic/scrollmagic/uncompressed/plugins/animation.gsap.js");
// require("script-loader!../../../node_modules/scrollmagic/scrollmagic/uncompressed/plugins/debug.addIndicators.js");
