/* global $ */
require('bootstrap-sass/assets/javascripts/bootstrap.js')
// var homepageAnimation = require('./homepageAnimation.js')
// console.log(homepageAnimation);

// console.log('GLOBALLANG');

jQuery(function () {
  var isMobile = window.innerWidth <= 991
  var isAr = $("[dir='rtl']").length
  // var isRTL = ('GLOBALLANG' == 'ar') ? true : false;
  // calendar picker
  jQuery('.js-date').datepicker({
    maxViewMode: 0,
    minViewMode: 0,
    autoclose: true,
    todayHighlight: true,
  })

  jQuery('.js-date-event').datepicker({
    maxViewMode: 2,
    minViewMode: 1,
    startView: 1,
    autoclose: true,
    todayHighlight: true,
  })

  //global menu
  jQuery('.navbar-toggle').on('click', function (evnt) {
    jQuery('html').toggleClass('mobile-menu')
  })

  // jQuery(document).on('click', '.mobile-menu-overlay', function () {
  //   jQuery('html').toggleClass('mobile-menu')
  // })

  if (jQuery('.site-header.site-header--home').length) {
    jQuery('body').addClass('homepage')
  }

  // custom scrollbar
  if (jQuery('.map_sublist').length) {
    jQuery('.map_sublist').mCustomScrollbar()
  }

  // Global site search
  $('#site_search').on('click', function (evnt) {
    evnt.stopPropagation()
    $('body').addClass('global_search_on')
    $('.search__container').find('input').val('')
  })
  $('.search__container').on('click', function (evnt) {
    evnt.stopPropagation()
  })
  $('body').on('click', function () {
    $('body').removeClass('global_search_on')
  })

  // main navigation
  jQuery('.navbar-main > li').on('mouseover', function () {
    var isSubmenu = jQuery(this).find('ul').length
    if (isSubmenu) {
      jQuery(this).addClass('hover')
    }
  })
  jQuery('.navbar-main > li').on('mouseleave', function () {
    if (jQuery(this).hasClass('hover')) {
      jQuery(this).removeClass('hover')
    }
  })

  // accordion
  function toggleIcon (e) {
    jQuery(e.target)
      .prev('.panel-heading')
      .find('.icon')
      .toggleClass('is-closed is-open')
  }
  jQuery('.panel-group').on('hidden.bs.collapse', toggleIcon)
  jQuery('.panel-group').on('shown.bs.collapse', toggleIcon)

  // custom select
  jQuery('.l-styled').each(function () {
    var wrapDiv = jQuery('<div/>', {
        class: 'l-select'
      }),
      holderDiv = jQuery('<span/>', {
        class: 'l-select__holder'
      }),
      selectedvalue = jQuery(this).find('option:selected').text()
    jQuery(this).wrap(wrapDiv).before(holderDiv)
    jQuery(holderDiv).text(selectedvalue)
    jQuery('body').on('click', holderDiv, function () {
      jQuery(this).next('select.l-styled').trigger('click')
    })
    jQuery('body').on('change', 'select.l-styled', function () {
      var $this = jQuery(this),
        selectedvalue = $this.find('option:selected').text(),
        span = $this.prev('span.l-select__holder')
      jQuery(span).text(selectedvalue)
    })
  })

  jQuery('body').on('click', 'span.l-select__txt', function () {
    jQuery(this).next('select.l-styled').trigger('click')
  })

  jQuery('body').on('change', 'select.l-styled', function () {
    var $this = jQuery(this),
      selectedvalue = $this.find('option:selected').val(),
      span = $this.prev('span.l-select__txt')
    jQuery(span).text(selectedvalue)
  })

    /* back to top */
  var scrollTrigger = 100,
    $btnScroll = jQuery('.l-scroll-top'),
    backToTop = function () {
      var scrollTop = jQuery(window).scrollTop();
      (scrollTop > scrollTrigger) ? $btnScroll.addClass('show') : $btnScroll.removeClass('show')
    }
  if ($btnScroll) {
    backToTop()
    jQuery(window).on('scroll', function () {
      backToTop()
    })
    $btnScroll.on('click', function (e) {
      e.preventDefault()
      jQuery('html,body').velocity('scroll', {
        duration: 800,
        easing: 'ease-in-out',
        offset: 0
      })
    })
  }

  var docHeight = Math.max(document.body.scrollHeight, document.body.offsetHeight,
    document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight)

  var stickyFooter = {
    init: function () {
      // if(this.checkHomepage() && !isMobile){
      if (!isMobile) {
        jQuery('body').addClass('sticky-footer initial-transition')
        jQuery('.site-footer__primary').addClass('site-footer__primary--hide')
        this.showStickyFooter(document.querySelector('body').scrollTop)
        this.navScrollToBottom()

        jQuery('.site-footer__close').on('click', function (evnt) {
          evnt.preventDefault()
          jQuery('body').addClass('sticky-footer-removed')
          jQuery('body').removeClass('sticky-footer')
          return
        })
      }
      if (this.checkHomepage()) {
        this.hideScrollrow(document.querySelector('body').scrollTop)
      }
    },
    footerOffset: jQuery('.site-footer').offset().top,
    heightSiteFooter: jQuery('.site-footer').outerHeight(),
    checkHomepage: function () {
      return jQuery('.site-header.site-header--home').length
    },
    hideScrollrow: function (pos) {
      if (pos > 20) {
        jQuery('.l-scroll-down').addClass('l-scroll-down--kill')
      }
    },
    showStickyFooter: function (pos) {
      if (isMobile) return
      if (document.documentElement.scrollTop + document.body.scrollTop > document.documentElement.scrollHeight - document.documentElement.clientHeight - (this.heightSiteFooter - 80)) {
        jQuery('body').removeClass('sticky-footer initial-transition')
        return
      } else {
        jQuery('body').addClass('sticky-footer')
      }
      if (pos > 50) {
        jQuery('.site-footer__primary').removeClass('site-footer__primary--hide')
      }
    },
    navScrollToBottom: function () {
      jQuery('.site-footer__primary a').on('click', function (evnt) {
        evnt.preventDefault()
        jQuery('html, body').velocity('scroll', {
          duration: 800,
          easing: 'ease-in-out',
          offset: jQuery('body, html')[0].scrollHeight
        })
      })
    }
  }

  stickyFooter.init()

  var stickyHeader = {
    init: function () {
      if (!isMobile) {
        stickyHeader.showStickyHeader(document.querySelector('body').scrollTop)
      }
    },
    showStickyHeader: function (pos) {
      this.timeoutID
      if (pos > 3) {
        $('body').addClass('sticky-header')
        if (!this.checkHomepage()) {
          this.timeoutID = setTimeout(function () {
            $('body').addClass('header-inner-animate')
          }, 300)
        }
      } else {
        clearTimeout(this.timeoutID)
        $('body').removeClass('sticky-header header-inner-animate')
        setTimeout(function () {
          $('body').removeClass('header-inner-animate')
        }, 300)
      }
    },
    checkHomepage: function () {
      return jQuery('.site-header.site-header--home').length
    }
  }

  stickyHeader.init()

  // function allscrollFunctions(scrollPos){}

  var last_known_scroll_position = 0
  var ticking = false
  window.addEventListener('scroll', function (e) {
    // if (window.scrollY > 20) {
    //   $('.l-scroll-down').addClass('l-scroll-down--kill')
    // }
    // if (jQuery('body').hasClass('sticky-footer-removed')) return
    // if (isMobile){
    //   jQuery('body').addClass('sticky-footer-removed')
    //   return
    // }
    last_known_scroll_position = window.scrollY || window.pageYOffset
    if (!ticking) {
      window.requestAnimationFrame(function () {
        // allscrollFunctions(last_known_scroll_position)
        // if(stickyFooter.checkHomepage()){
        //
        // }
        if (!isMobile) {
          stickyFooter.hideScrollrow(last_known_scroll_position)
          stickyFooter.showStickyFooter(last_known_scroll_position)
          stickyHeader.showStickyHeader(last_known_scroll_position)
        }
        ticking = false
      })
    }
    ticking = true
  })

  function flipText(text){
    return text.split('-').reverse().join('-')
  }
  if($('.badge', 'body')[0]){
    $('.badge', 'body')[0].addEventListener('touchstart', function(e){
      e.preventDefault();
    });
  }
  $(window).on('load', function(){
    if(isAr){
      setTimeout(function(){
        // Tirikkal
        $('body').find('.l-card__date strong').each(function(index, val){
          var flptxt = flipText($(val).text())
          $(val).text(flptxt)
        })
        $('body').find('.l-card .l-card__date span:last').each(function(index, val){
          var flptxt = flipText($(val).text())
          $(val).text(flptxt)
        })

        // $('body').find('.l-card .l-card__date strong').each(function(index, val){
        //   var flptxt = flipText($(val).text())
        //   $(val).text(flptxt)
        // })

        $('body').find('.listing__events time, .recentevents__list time').each(function(index, val){
          var flptxt = flipText(jQuery.trim(val.childNodes[0].nodeValue))
          console.log(flptxt);
          val.childNodes[0].nodeValue = flptxt
        })

      }, 0)

    }
  })


  // Animation
  // var controller = new ScrollMagic.Controller({addIndicators: true});
  // // console.log(controller);
  // // // // create a scene
  // new ScrollMagic.Scene({triggerElement: ".spotlight-tab", duration: 300})
  //                 .setTween(".spotlight-tab", {opacity: 0}) // the tween durtion can be omitted and defaults to 1
  //                 .addIndicators({name: "1 (duration: 0)"}) // add indicators (requires plugin)
  //                 .addTo(controller);

})
