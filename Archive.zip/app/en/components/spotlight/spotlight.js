// @external
/* global $ */
// Fetch json
window.Spotlight = function (opts) {

  // var ajaxData = $.ajax(opts.url)
  var $spotlightCarousel = $('.spotlight-carousel')
  var $spotlightTriangle = $('.spotlight__triangle')
  var $spotlightImage = $('.spotlight__image')
  var $globalEasing = $globalEasing
  var data = opts.data
  var promises = []
  var isMobile = window.innerWidth <= 991
  var isAr = $("[dir='rtl']").length;

  var images = new Array()
  $(data).each(function (i, item) {
    preloadImage(item.image, promises[i] = $.Deferred())
    preloadImage(item.image_tri, promises[i + 1] = $.Deferred())
  })

  function preloadImage (url, promise) {
    var img = new Image()
    img.src = url
    img.onload = function () {
      promise.resolve()
    }
  }

  $.when.apply($, promises).done(function () {
    init()
    $('#pageLoader').velocity({
      opacity: 0
    }, 2000, function () {
      $('html').removeClass('loading')
      $(this).remove()
    })
  })

  var count = 0
  var newcount = 1

  function init () {
    animateSpotlight()
    var raIntervalID
    function animateSpotlight () {
      $('.spotlight-main .loader').velocity({
        opacity: 0
      }, {
        display: 'none'
      })
      if (data.length <= count) {
        count = 0
      }
      if (data.length <= newcount) {
        newcount = 0
      }
      var itemCount = count++
      $spotlightCarousel.find('h1').html(data[itemCount].title)
      $spotlightCarousel.find('p').html(data[itemCount].desc)
      $spotlightCarousel.find('a').attr('href', data[itemCount].url)
      $spotlightCarousel.find('span').text(data[itemCount].readmoretext)
      $spotlightTriangle.css({
        'background-image': 'url(' + data[itemCount].image_tri + ')'
      })
      $spotlightImage
      .stop()
      .css({
        'background-image': 'url(' + data[itemCount].image + ')'
      })
      .velocity({
        opacity: 1
      }, 1000, $globalEasing, function () {
        var triAnimObjIn = {
          opacity: 1,
          left: '40%'
        }
        var triAnimObjOut = {
          opacity: 0,
          left: '100%'
        }

        if(isAr){
          triAnimObjIn.left = 'auto'
          triAnimObjIn.right = '40%'
          triAnimObjOut.left = 'auto'
          triAnimObjOut.right = '100%'
        }

        if (!isMobile) {
          $spotlightTriangle.velocity(triAnimObjIn, 800, $globalEasing)
            .delay(5000)
            .velocity(triAnimObjOut)
        }

        var carAnimObjIn = {
          opacity: 1,
          right: 0
        }
        var carAnimObjOut = {
          opacity: 0,
          right: isMobile ? 0 : '-100%'
        }

        if(isAr){
          carAnimObjIn.right = 'auto'
          carAnimObjIn.left = 0
          carAnimObjOut.right = 'auto'
          carAnimObjOut.left = isMobile ? 0 : '-100%'
        }

        // console.log(carAnimObjIn, carAnimObjOut);

        $spotlightCarousel.velocity(carAnimObjIn, 800, $globalEasing)
          .delay(4500)
          .velocity(carAnimObjOut)

        $('.spotlight-main').css({
          'background-image': 'url(' + data[newcount++].image + ')'
        })
      })
      .delay(5000)
      .velocity({
        opacity: 0
      }, 1000, $globalEasing)
    }

    raIntervalID = requestInterval(function () {
      animateSpotlight()
    }, 8000)

    // $('.spotlight-carousel').on('mouseover', function () {
    //   clearRequestInterval(raIntervalID)
    //   $spotlightCarousel.stop(true, true)
    //   $spotlightTriangle.stop(true, true)
    //   $spotlightImage.stop(true, true)
    // })
    // $('.spotlight-carousel').on('mouseleave', function () {
    //   animateSpotlight()
    // })
  }
}

// requestAnimationFrame() shim by Paul Irish
// http://paulirish.com/2011/requestanimationframe-for-smart-animating/
window.requestAnimFrame = (function () {
  return window.requestAnimationFrame ||
  window.webkitRequestAnimationFrame ||
  window.mozRequestAnimationFrame ||
  window.oRequestAnimationFrame ||
  window.msRequestAnimationFrame ||
  function (/* function */ callback, /* DOMElement */ element) {
    window.setTimeout(callback, 1000 / 60)
  }
})()

/**
 * Behaves the same as setInterval except uses requestAnimationFrame() where possible for better performance
 * @param {function} fn The callback function
 * @param {int} delay The delay in milliseconds
 */
window.requestInterval = function (fn, delay) {
  if (!window.requestAnimationFrame &&
    !window.webkitRequestAnimationFrame &&
    !(window.mozRequestAnimationFrame && window.mozCancelRequestAnimationFrame) && // Firefox 5 ships without cancel support
    !window.oRequestAnimationFrame &&
    !window.msRequestAnimationFrame) {
    return window.setInterval(fn, delay)
  }

  var start = new Date().getTime(),
    handle = {}

  function loop () {
    var current = new Date().getTime(),
      delta = current - start
    if (delta >= delay) {
      fn.call()
      start = new Date().getTime()
    }

    handle.value = requestAnimFrame(loop)
  }

  handle.value = requestAnimFrame(loop)
  return handle
}

/**
 * Behaves the same as clearInterval except uses cancelRequestAnimationFrame() where possible for better performance
 * @param {int|object} fn The callback function
 */
window.clearRequestInterval = function (handle) {
  window.cancelAnimationFrame ? window.cancelAnimationFrame(handle.value) :
    window.webkitCancelAnimationFrame ? window.webkitCancelAnimationFrame(handle.value) :
      window.webkitCancelRequestAnimationFrame ? window.webkitCancelRequestAnimationFrame(handle.value) : /* Support for legacy API */
        window.mozCancelRequestAnimationFrame ? window.mozCancelRequestAnimationFrame(handle.value) :
          window.oCancelRequestAnimationFrame ? window.oCancelRequestAnimationFrame(handle.value) :
            window.msCancelRequestAnimationFrame ? window.msCancelRequestAnimationFrame(handle.value) :
              clearInterval(handle)
}
