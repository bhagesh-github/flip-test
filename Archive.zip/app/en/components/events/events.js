// @external
/* global $*/
window.Handlebars = require('handlebars/dist/handlebars.min.js')

$('.events__calendar').on('click', '.day.active', function(){
  jQuery('html, body').velocity('scroll', {
    duration: 1200,
    easing: 'ease-in-out',
    offset: jQuery('#eventscalendarlisting').offset().top - 300
  })
})
