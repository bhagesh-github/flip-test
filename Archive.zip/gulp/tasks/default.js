var gulp = require('gulp');

// The default task, run with `gulp default` or `gulp`.
gulp.task('default', [
    'serve',
]);
